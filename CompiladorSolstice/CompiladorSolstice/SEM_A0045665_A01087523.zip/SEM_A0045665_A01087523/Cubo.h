#include<iostream>
#include<string>

class Cubo {
	public:
	Cubo(void);
	int cubo;
};