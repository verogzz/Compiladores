#include "Memoria.h"

Memoria::Memoria(){
	m_b.clear();
	m_s.clear();
	m_i.clear();
	m_d.clear();
};

Memoria::~Memoria(){
	m_b.clear();
	m_s.clear();
	m_i.clear();
	m_d.clear();
};

