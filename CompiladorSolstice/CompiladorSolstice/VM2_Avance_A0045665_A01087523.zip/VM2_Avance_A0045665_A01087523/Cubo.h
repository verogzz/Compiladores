#ifndef CUBO_H
#define CUBO_H
#include<iostream>
#include<string>

class Cubo {
public:
	Cubo();
	int cubo[4][4][15];
};

#endif