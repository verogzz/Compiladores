#ifndef CUBO_H
#define CUBO_H
#include<iostream>
#include<string>

class Cubo {
public:
	Cubo(void);
	int cubo[4][4][14];
};

#endif